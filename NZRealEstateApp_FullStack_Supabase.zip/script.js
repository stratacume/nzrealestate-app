
const supabaseUrl = 'https://YOUR_PROJECT_ID.supabase.co';
const supabaseKey = 'YOUR_PUBLIC_ANON_KEY';
const supabase = supabase.createClient(supabaseUrl, supabaseKey);

document.getElementById('listingForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const price = document.getElementById('price').value;
  const location = document.getElementById('location').value;
  const contact_email = document.getElementById('contact_email').value;

  const { error } = await supabase.from('Listings').insert([{ title, description, price, location, contact_email }]);
  if (error) return alert(error.message);
  alert("Listing created!");
  window.location.reload();
});

async function fetchListings() {
  let { data: listings, error } = await supabase.from('Listings').select('*');
  if (error) return console.error(error);
  const container = document.getElementById('propertyContainer');
  listings.forEach(listing => {
    const div = document.createElement('div');
    div.innerHTML = `<h3>${listing.title}</h3><p>${listing.description}</p><p>${listing.price}</p><p>${listing.location}</p><p>Contact: ${listing.contact_email}</p>`;
    container.appendChild(div);
  });
}
fetchListings();
